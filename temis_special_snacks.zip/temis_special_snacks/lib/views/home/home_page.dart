import 'package:flutter/material.dart';
import 'package:temis_special_snacks/utils/colors.dart';
import 'package:temis_special_snacks/views/account/account_page.dart';
import 'package:temis_special_snacks/views/auth/sign_in_page.dart';
import 'package:temis_special_snacks/views/auth/sign_up_page.dart';
import 'package:temis_special_snacks/views/cart/cart_history.dart';
import 'package:temis_special_snacks/views/home/temi_main_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  List pages = [
    const TemiMainPage(),
    Container(child: Text("History page"),),
    const CartHistory(),
    const AccountPage(),
  ];

  void onTapNav(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: AppColors.mainColor,
        unselectedItemColor: Colors.amberAccent,
        currentIndex: _selectedIndex,
        showUnselectedLabels: false,
        unselectedFontSize: 0.0,
        onTap: onTapNav,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
            ),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.archive,
            ),
            label: "History",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.shopping_cart,
            ),
            label: "Cart",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
            ),
            label: "Me",
          ),
        ],
      ),
    );
  }
}
