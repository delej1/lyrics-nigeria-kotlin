import 'package:get/get.dart';
import 'package:temis_special_snacks/views/auth/sign_in_page.dart';
import 'package:temis_special_snacks/views/auth/sign_up_page.dart';
import 'package:temis_special_snacks/views/cart/cart_page.dart';
import 'package:temis_special_snacks/views/home/home_page.dart';
import 'package:temis_special_snacks/views/home/temi_main_page.dart';
import 'package:temis_special_snacks/views/product/popular_product_detail.dart';
import 'package:temis_special_snacks/views/splash/splash_screen.dart';
import '../views/product/recommended_product_detail.dart';

class RouteHelper{
  static const String splashPage = "/splash-page";
  static const String initial = "/";
  static const String popularProduct="/popular-product";
  static const String recommendedProduct="/recommended-product";
  static const String cartPage = "/cart-page";
  static const String signUp = "/sign-up";
  static const String signIn = "/sign-in";


  static String getSplashPage()=>'$splashPage';
  static String getInitial()=>'$initial';
  static String getPopularProduct(int pageId, String page)=>'$popularProduct?pageId=$pageId&page=$page';
  static String getRecommendedProduct(int pageId, String page)=>'$recommendedProduct?pageId=$pageId&page=$page';
  static String getCartPage()=>'$cartPage';
  static String getSignUpPage()=>'$signUp';
  static String getSignInPage()=>'$signIn';


  static List<GetPage>routes=[
    GetPage(name: splashPage, page: ()=>const SplashScreen()),

    GetPage(name: initial, page: ()=>const HomePage()),

    GetPage(name: signUp, page: (){
      return const SignUpPage();
    }, transition: Transition.fade),

    GetPage(name: signIn, page: (){
      return const SignInPage();
    }, transition: Transition.fade),

    GetPage(name: popularProduct, page: () {
      var pageId = Get.parameters['pageId'];
      var page = Get.parameters["page"];
      return PopularProductDetail(pageId:int.parse(pageId!), page:page!);
      },
    transition: Transition.fadeIn),

    GetPage(name: recommendedProduct, page: () {
      var pageId = Get.parameters['pageId'];
      var page = Get.parameters["page"];
      return RecommendedProductDetail(pageId:int.parse(pageId!), page:page!);
    },
        transition: Transition.fadeIn),
    GetPage(name: cartPage, page: (){
      return const CartPage();
    },
    transition: Transition.fadeIn),
  ];

}