class AppConstants{
  static const String appName ="Temi's Special Snacks";
  static const int appVersion= 1;

  static const String baseUrl = "http://192.168.43.47:8000";
  static const String popularProductsUri= "/api/v1/products/popular";
  static const String recommendedProductsUri= "/api/v1/products/recommended";
  static const String uploadUrl = "/uploads/";

  static const String token="";
  static const String cartList="cart-list";
  static const String cartHistoryList="cart-history-list";

  static const String registrationUri="/api/v1/auth/register";
  static const String loginUri="/api/v1/auth/login";
  static const String userInfoUri="/api/v1/customer/info";

  static const String phone="";
  static const String password="";
}