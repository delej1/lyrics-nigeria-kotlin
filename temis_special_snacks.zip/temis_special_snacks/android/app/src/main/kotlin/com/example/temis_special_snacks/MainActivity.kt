package com.example.temis_special_snacks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
